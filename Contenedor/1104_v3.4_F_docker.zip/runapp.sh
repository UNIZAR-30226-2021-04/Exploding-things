#!/bin/bash

sudo docker stop rocketruckus
sudo docker rm rocketruckus

cd tomcat
sudo docker build -t margarethamilton/rocketruckus:latest .
sudo docker login --username=margarethamilton --password=MargaretHamilton2021
sudo docker push margarethamilton/rocketruckus:latest
sudo docker run -d --name rocketruckus -p 8080:8080 margarethamilton/rocketruckus:latest
