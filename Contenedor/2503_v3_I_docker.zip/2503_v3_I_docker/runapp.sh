#!/bin/bash

sudo docker stop rocketruckus
sudo docker rm rocketruckus

cd tomcat
sudo docker build -t margarethamilton/rocketruckus:latest .
sudo docker login --username=margarethamilton --password=MargaretHamilton2021
sudo docker push margarethamilton/rocketruckus:latest
