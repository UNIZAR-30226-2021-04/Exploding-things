#!/bin/bash

cd tomcat
sudo docker build -t margarethamilton/rocketruckus:iteration2 .
sudo docker login --username=margarethamilton --password=MargaretHamilton2021
sudo docker push margarethamilton/rocketruckus:iteration2
